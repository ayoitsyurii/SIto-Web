import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import multer from 'multer'
import cors from 'cors'
import { promises as fs } from 'fs';

const app = express();
const port = 4000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.static(path.join(__dirname, 'frontend')));

app.use(cors());

app.use(express.json());

let lastOrderId = 0;
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
      cb(null, 'immagini/');
  },
  filename: (req, file, cb) => {
      cb(null, file.originalname);
  }
});

const upload = multer({ storage: storage });

app.use('/immagini', express.static(path.join(__dirname, 'immagini')));

app.post('/singolo', upload.single('file'), (req, res) => {
  res.send({ file: req.file });
});

app.post('/multiplo', upload.array('file', 6), (req, res) => {
  res.send({ files: req.files });
});

app.get('/prodotti.json', (req, res) => {
  fs.readFile(path.join(__dirname, 'backend', 'prodotti.json'), 'utf8')
  .then(data => {
    const prodotti = JSON.parse(data);
    
    res.json(prodotti);
  })
  .catch(err => {
    res.status(500).json({ message: 'Errore nel caricamento dei prodotti' });
  });
})
app.post('/prodotti.json', upload.array('file', 6), (req, res) => {
  const immagini = {};

  if (req.files && req.files.length > 0) {
      req.files.forEach((file, index) => {
          immagini[`immagine${index + 1}`] = file.filename;
      });
  }

  const nuovoProdotto = {
      'id-prodotto': req.body['id-prodotto'],
      titolo: req.body.titolo,
      categoria: req.body.categoria,
      descrizione: req.body.descrizione,
      condizioni: req.body.condizioni,
      prezzo: req.body.prezzo,
      immagini: immagini
  };

  fs.readFile(path.join(__dirname, 'backend', 'prodotti.json'), 'utf8')
    .then(data => {
      const prodotti = JSON.parse(data);
      prodotti.push(nuovoProdotto);
      return fs.writeFile(path.join(__dirname, 'backend', 'prodotti.json'), JSON.stringify(prodotti, null, 2));
    })
    .then(() => {
      res.status(201).json({ message: 'Prodotto aggiunto con successo' });
    })
    .catch(err => {
      res.status(500).json({ message: 'Errore nel salvataggio del prodotto' });
    });
});
  app.delete('/prodotti/:id', (req, res) => {
    const idDaRimuovere = req.params.id;

    fs.readFile(path.join(__dirname, 'backend', 'prodotti.json'), 'utf8')
        .then(data => {
            const prodotti = JSON.parse(data);
            const nuoviProdotti = prodotti.filter(prodotto => prodotto['id-prodotto'] !== idDaRimuovere);
            return fs.writeFile(path.join(__dirname, 'backend', 'prodotti.json'), JSON.stringify(nuoviProdotti, null, 2));
        })
        .then(() => {
            res.status(200).json({ message: 'Prodotto rimosso con successo' });
        })
        .catch(err => {
            res.status(500).json({ message: 'Errore nel rimuovere il prodotto' });
        });
});
app.put('/prodotti/:id', upload.single('immagine1'), (req, res) => {
    const idDaModificare = req.params.id;

    fs.readFile(path.join(__dirname, 'backend', 'prodotti.json'), 'utf8')
        .then(data => {
            const prodotti = JSON.parse(data);
            const prodottoDaModificare = prodotti.find(prodotto => prodotto['id-prodotto'] === idDaModificare);

            if (!prodottoDaModificare) {
                return res.status(404).json({ message: 'Prodotto non trovato' });
            }

            prodottoDaModificare.titolo = req.body.titolo || prodottoDaModificare.titolo;
            prodottoDaModificare.categoria = req.body.categoria || prodottoDaModificare.categoria;
            prodottoDaModificare.descrizione = req.body.descrizione || prodottoDaModificare.descrizione;
            prodottoDaModificare.condizioni = req.body.condizioni || prodottoDaModificare.condizioni;
            prodottoDaModificare.prezzo = req.body.prezzo || prodottoDaModificare.prezzo;

          
            if (req.file) {
                prodottoDaModificare.immagini.immagine1 = req.file.filename;
            }

            return fs.writeFile(path.join(__dirname, 'backend', 'prodotti.json'), JSON.stringify(prodotti, null, 2));
        })
        .then(() => {
            res.status(200).json({ message: 'Prodotto modificato con successo' });
        })
        .catch(err => {
            res.status(500).json({ message: 'Errore nel modificare il prodotto' });
        });
});
    
app.post('/ordini.json', (req, res) => {
  const nuovoOrdine = req.body;
  nuovoOrdine.id = lastOrderId;
  
  fs.readFile(path.join(__dirname, 'backend', 'ordini.json'), 'utf8')
    .then(data => {
      const ordini = JSON.parse(data);
      ordini.push(req.body);
      return fs.writeFile(path.join(__dirname, 'backend', 'ordini.json'), JSON.stringify(ordini, null, 2));
    })
    .then(() => {
      lastOrderId++
      res.json({ success: true });
    })
    .catch(err => {
      console.error('Errore nel salvataggio dell\'ordine:', err);
      res.status(500).json({ message: 'Errore nel salvataggio dell\'ordine' });
    });
});

app.get('/ordini.json', (req, res)=>{
  fs.readFile(path.join(__dirname, 'backend', 'ordini.json'), 'utf8')
  .then(data => {
    const ordini = JSON.parse(data);
    if (ordini.length > 0) {
      lastOrderId = ordini.length +1; 
    } else{
      lastOrderId = 1;
    }
   
    res.json(ordini);
  })
  .catch(err => {
    res.status(500).json({ message: 'Errore nel caricamento dei prodotti' });
  });
})
app.delete('/ordini/:id', (req, res) => {
  const idDaRimuovere = Number(req.params.id); 

  fs.readFile(path.join(__dirname, 'backend', 'ordini.json'), 'utf8')
      .then(data => {
          const ordini = JSON.parse(data);
          const nuoviOrdini = ordini.filter(ordine => ordine.id !== idDaRimuovere);
          return fs.writeFile(path.join(__dirname, 'backend', 'ordini.json'), JSON.stringify(nuoviOrdini, null, 2));
      })
      .then(() => {
        if (nuoviOrdini.length === 0) {
          lastOrderId = 0;
        }
          res.status(200).json({ message: 'Ordine rimosso con successo' });
      })
      .catch(err => {
          res.status(500).json({ message: 'Errore nel rimuovere l\'ordine' });
      });
});
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend'));
});

app.listen(port, () => {
  console.log(`Server in esecuzione su http://localhost:${port}`);
});